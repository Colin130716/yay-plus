#!/bin/bash

cat pwd
